
package net.ccbluex.liquidbounce.api.minecraft.entity

interface IEnumCreatureAttribute
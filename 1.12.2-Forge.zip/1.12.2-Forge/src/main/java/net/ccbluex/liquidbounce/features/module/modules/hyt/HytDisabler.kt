package net.ccbluex.liquidbounce.features.module.modules.hyt


import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.injection.backend.unwrap
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.network.play.client.*

@ModuleInfo(name = "Disabler",description = "disable anti cheat", category = ModuleCategory.EXPLOIT)
class Disabler: Module() {
    val AutoBlockFix = BoolValue("AutoBlockFix",true)
    private var debug = BoolValue("Debug", false)
    private var delayValue = IntegerValue("LogDelay", 40, 1, 200).displayable { debug.get() }


    val target = (LiquidBounce.moduleManager[KillAura::class.java] as KillAura).target



    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet.unwrap()
        val killAura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura
    
        if (packet is CPacketPlayerTryUseItemOnBlock && killAura.target != null && killAura.target != null  && AutoBlockFix.get()) {
            if (debug.get()) {
                val timer = MSTimer()
                if (timer.hasTimePassed(delayValue.get().toLong() * 1000)) {
                    debugMessage("AutoBlockFix in GrimAC")
                    timer.reset()
                }
            }
            event.cancelEvent()
        }
 
  
    }
    fun debugMessage(str: String) {// C08 is FakeAB OK? 我还没试 我丢你我的
        if (debug.get()) {
            alert("§7[§c§lDisabler§7] §b$str")
        }
    }
    override val tag: String?
        get() = "GrimAC"
}

package net.ccbluex.liquidbounce.api.minecraft.creativetabs

interface ICreativeTabs {
    var backgroundImageName: String
}
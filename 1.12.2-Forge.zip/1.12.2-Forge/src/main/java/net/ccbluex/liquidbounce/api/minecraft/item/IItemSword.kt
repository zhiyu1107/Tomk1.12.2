
package net.ccbluex.liquidbounce.api.minecraft.item

interface IItemSword {
    val damageVsEntity: Float
}
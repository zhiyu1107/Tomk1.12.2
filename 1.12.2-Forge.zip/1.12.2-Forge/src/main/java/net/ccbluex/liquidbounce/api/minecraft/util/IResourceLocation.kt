
package net.ccbluex.liquidbounce.api.minecraft.util

interface IResourceLocation {
    val resourcePath: String
}
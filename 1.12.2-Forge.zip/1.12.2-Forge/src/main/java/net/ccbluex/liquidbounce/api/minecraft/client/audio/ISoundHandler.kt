
package net.ccbluex.liquidbounce.api.minecraft.client.audio

interface ISoundHandler {
    fun playSound(name: String, pitch: Float)
}